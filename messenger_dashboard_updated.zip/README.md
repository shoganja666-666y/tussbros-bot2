# Messenger Dashboard (configuration-only)

This Flask app provides a password-protected dashboard for saved settings, reply-rule configuration, theme preferences, and activity logs.

**Important limitation:** this project does not connect to Messenger or send replies. Group-name and nickname forms only record requests. The cookie JSON panel checks syntax and basic structure only; never paste real session cookies into it.

## Deploy on Render

1. Upload these files to a GitHub repository: `app.py`, `requirements.txt`, and `Procfile`.
2. In Render, create a **New Web Service** connected to that repository.
3. Use the following settings:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
4. In the service's **Environment** settings, add:
   - `SECRET_KEY`: a new random secret (generate with `python -c "import secrets; print(secrets.token_hex(32))"` on a computer with Python, or use a trusted password manager's random generator).
   - `ADMIN_PASSWORD`: a strong, unique dashboard password.
   - `COOKIE_SECURE`: `1` for HTTPS (the default).
5. If you want settings and logs to survive restarts/redeploys, attach a persistent disk to the service, mount it at `/var/data`, and add `DB_PATH=/var/data/dashboard.db`. Without a persistent disk, SQLite data may be lost when the service is replaced or its filesystem resets.
6. Save and deploy. Open the Render URL and sign in with the `ADMIN_PASSWORD` value.

## Local run

Set `SECRET_KEY` and `ADMIN_PASSWORD` in your shell environment, then run:

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Files

- `app.py`: Flask app and SQLite schema initialization.
- `requirements.txt`: Python dependencies.
- `Procfile`: Gunicorn start command.
